//
//  YKImagePicker.h
//  YKImagePicker
//
//  Created by yyk on 2019/4/9.
//  Copyright © 2019年 yyk. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YKImagePicker.
FOUNDATION_EXPORT double YKImagePickerVersionNumber;

//! Project version string for YKImagePicker.
FOUNDATION_EXPORT const unsigned char YKImagePickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YKImagePicker/PublicHeader.h>

#import <YKImagePicker/YKShowImagesView.h>

